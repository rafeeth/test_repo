Read Me:

    What is this Tool?
        > This is a tool to generate/write Chronos firmware configuration parameters.
        > This tool is for internal purpose, never share it outside MPS

    How to use?
        > select "_config.json" file to load base configuration items
        > select serial port to which meter is connected
        > read meter to load actual configuration of the firmware
        > browse through each pages across all section and make changes as necessary
        > use "Capture changes" to validate and update configuration changes on UI
        > at preview, review final configuration
        > save the modified configuration
        > write the modified configuration to meter
        > Remember to initialize the meter on new configuration write, in factory which is expected to be on calibration stage.

    Resolution of instantaneous variables?
        > Resolution of voltage is 3 decimals .i.e 240v is read/written as 240000
        > Resolution of current is 4 decimals .i.e 5A is read/written as 50000
        > Resolution of power is 4 decimal of watts .i.e 1.2kW is read/written as 12000000 
        > Resolution of PF is 2 decimals, .i.e 0.5PF is read/written as 500
        > Resolution of frequency is 2 decimals .i.e 50Hz is read/written as 5000
        > Resolution of temperature is 1 decimal .i.e 25 deg C is read/written as 250
