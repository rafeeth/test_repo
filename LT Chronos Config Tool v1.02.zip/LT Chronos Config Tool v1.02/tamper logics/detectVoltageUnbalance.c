if (logic is TamperDetectionDisabled)
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    {
        if ((Vmax-Vmin > OT_1)
            and (min voltage > OT_2)
            and (min current > OT_3)
            and (max current > OT_4))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((Vmax-Vmin < RT_1)
            and (min voltage > RT_2)
            and (min current > RT_3)
            and (max current > RT_4))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic2:
    {
        if ((Vmax-Vmin > OT_1)
            and (min voltage > OT_2)
            and (min current > OT_3)
            and (max current > OT_4))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((Vmax-Vmin < RT_1)
            or (min voltage < RT_2)
            or (min current < RT_3)
            or (max current < RT_4))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

     case TamperDetectionLogic3:
    {
        if ((Vmax-Vmin > OT_1)
            and (min voltage > OT_2)
            and (min voltage < OT_3))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((Vmax-Vmin < RT_1)
            or (min voltage < RT_2)
            or (min voltage > RT_3))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
}