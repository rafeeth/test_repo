if ((logic is TamperDetectionDisabled)
        or ((noBypassTamperCheck) and (current bypass running))
        or (relay state is not RelaySwitchConnected))
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    {
        if ((Imax-Imin > OT_1)
            and (bypass current < OT_2)
            and (min voltage > OT_3)
            and (min current > OT_4)
            and (avg current > OT_5))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((Imax-Imin < RT_1)
            and (bypass current < RT_2)
            and (min voltage > RT_3)
            and (min current > RT_4)
            and (avg current > RT_5))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic2:
    {
        if ((Imax-Imin > OT_1)
            and (bypass current > OT_2)
            and (min voltage > OT_3)
            and (min current > OT_4)
            and (avg current > OT_5))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((Imax-Imin < RT_1)
            and (bypass current < RT_2)
            and (min voltage > RT_3)
            and (min current > RT_4)
            and (avg current > RT_5))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic3:
    {
        if(metering mode is not unidirectional) break;
        
         if ((Imax-Imin > OT_1)
            and (bypass current < OT_2)
            and (avg current > OT_5)
            and (avg current < OT_7))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((Imax-Imin < RT_1)
            and (bypass current < RT_2)
            and (avg current > RT_5)
            and (avg current < RT_7))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic4:
    {
        if ((Imax-Imin > OT_1)
            and (bypass current < OT_2)
            and (min voltage > OT_3)
            and (max current > OT_7)
            and (avg current > OT_5))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((Imax-Imin < RT_1)
            and (bypass current < RT_2)
            and (min voltage > RT_3)
            and (max current > RT_7)
            and (avg current > RT_5))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic5:
    {
        if ((Imax-Imin > OT_1)
            and (bypass current > OT_2)
            and (min voltage > OT_3)
            and (max current > OT_7)
            and (avg current > OT_5))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((Imax-Imin < RT_1)
            and (bypass current < RT_2)
            and (min voltage > RT_3)
            and (max current > RT_7)
            and (avg current > RT_5))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
}