if (logic is TamperDetectionDisabled)
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    if (THD Voltage > OT_1)
        tamperState = TamperStateOccurrence;
    else if (THD Voltage < RT_1)
        tamperState = TamperStateRecovery;
    break;
}