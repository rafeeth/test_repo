if (logic is TamperDetectionDisabled)
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    if (THD Current > OT_1)
        tamperState = TamperStateOccurrence;
    else if (THD Current < RT_1)
        tamperState = TamperStateRecovery;
    break;
}