if (logic is TamperDetectionDisabled)
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    {
        if (((max voltage > OT_3) and (min voltage < OT_4) and (max current > OT_5))
            or (frequency > OT_1) or (frequency < OT_2))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((max voltage < RT_3) and (min voltage > RT_4) and (max current > RT_5)
            and (frequency > OT_2) and (frequency < OT_1))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic2:
    {
        if (((max voltage > OT_3) and (min voltage < OT_4) 
            and ((max current > OT_5) or (neutral current > OT_5)))
            or (frequency > OT_1) or (frequency < OT_2))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((max voltage < RT_3)
            and (min voltage > RT_4)
            and (max current > RT_5)
            and (frequency > OT_2)
            and (frequency < OT_1))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
    
    case TamperDetectionLogic3:
    {
        if (((two phase voltage > OT_3) and (min voltage < OT_4) 
            and ((max current > OT_5) or (neutral current > OT_5)))
            or (frequency > OT_1) or (frequency < OT_2))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((max voltage < RT_3)
            and (min voltage > RT_4)
            and (max current > RT_5)
            and (frequency > OT_2)
            and (frequency < OT_1))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
}