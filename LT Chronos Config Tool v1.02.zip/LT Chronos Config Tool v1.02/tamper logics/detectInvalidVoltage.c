tamperStatus = Unknown;

if (logic == TamperDetectionDisabled)
    return;

standard logic