if (logic is TamperDetectionDisabled)
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    if ((neutral current > OT_1) and (min current <= OT_2))
        tamperState = TamperStateOccurrence;
    else if (neutral current < RT_1)
        tamperState = TamperStateRecovery;
    break;

    case TamperDetectionLogic2:
    if ((neutral current > OT_1) and (max current <= OT_2))
        tamperState = TamperStateOccurrence;
    else if (neutral current < RT_1)
        tamperState = TamperStateRecovery;
    break;

    case TamperDetectionLogic3:
    if ((neutral current > OT_1) and (bypass current > OT_2))
        tamperState = TamperStateOccurrence;
    else if ((neutral current < RT_1) and (bypass current < RT_2))
        tamperState = TamperStateRecovery;
    break;
}