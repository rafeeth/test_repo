if (logic is TamperDetectionDisabled)
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    {
        if ((voltageRybCheck and voltage sequence is PhaseSequenceRBY)
            or (currentRybCheck and current sequence is PhaseSequenceRBY))
        {
            tamperState = TamperStateOccurrence;
        }
        else tamperState = TamperStateRecovery;
    }
    break;

    case TamperDetectionLogic2:
    {
        if (((voltageRybCheck and voltage sequence is PhaseSequenceRBY)
            or (currentRybCheck and current sequence is PhaseSequenceRBY))
            and ((min voltage > OT_1) 
            and (min current > OT_2)))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((min voltage > RT_1) 
            and (min current > RT_2))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
}