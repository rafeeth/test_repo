if ((logic is TamperDetectionDisabled)
    or (relay state is not RelaySwitchConnected)
    or (energyLogic is not EnergyLogicUnidirectional))
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    {
        tamperState = TamperStateRecovery;

        if (kW is - ve)
        {            
            if ((phase current > OT_3) and ((net kW < OT_2) or (phase kW > OT_1 and phase PF > OT_4)))
            {
                tamperState = TamperStateOccurrence;
            }
        }
    }
    break;

    case TamperDetectionLogic2:
    {        
        if (kW is - ve)
        {
            if (((net kW < OT_2) or (phase kW > OT_1))
                and ((phase current > OT_3)
                and (phase voltage > OT_5)
                and (phase PF > OT_4)))
            {
                tamperState = TamperStateOccurrence;
            }
        }
        else if ((phase current > RT_3)
            and (phase kW > RT_1)
            and (phase voltage > RT_5)
            and (phase PF > RT_4))
        {
            tamperState = TamperStateRecovery;

        }
    }
    break;

    case TamperDetectionLogic3:
    {
        tamperState = TamperStateRecovery;
        low PF = 0;
        if ((kW is -ve) and (Voltage > 48 volts))
        {
            if ((PF > 0.545) or (Bypass current > 2.0 Amps))
                tamperState = TamperStateOccurrence;
            else low PF = 1;
        }

        if ((net kW <= -24 watts)
            and (All three phase are reverse))
        {
            low PF = 0;
            tamperState = TamperStateOccurrence;
        }
    }
    break;
    
    case TamperDetectionLogic4:
    {
        tamperState = TamperStateUnknown;
        if (kW is - ve)
        {
            if ((phase current > OT_3) and ((net kW < OT_2) or (phase kW > OT_1 and phase PF > OT_4)))
            {
                tamperState = TamperStateOccurrence;
            }
        }
        else tamperState = TamperStateRecovery;
    }
    break;

    
    case TamperDetectionLogic5:
    {
        tamperState = TamperStateUnknown;
        if (kW is - ve)
        {
            if ((phase current > OT_3)
                && (phase voltage > OT_5)
                && (net PF > OT_4))
                tamperState = TamperStateOccurrence;
        }
        else
        {
            if ((phase current > RT_3)
                && (phase voltage > RT_5)
                && (net PF > RT_4))
                tamperState = TamperStateRecovery;
        }
    }
    break;
}
