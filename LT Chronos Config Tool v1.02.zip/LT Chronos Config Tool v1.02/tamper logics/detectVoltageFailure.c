if (logic == TamperDetectionDisabled)
{
    tamperState = TamperStateUnknown;
    exit;
}

switch (logic)
{
    case TamperDetectionLogic1:
    default:
    {
        if ((phase_voltage < OT_1)
            and (phase_current > OT_3)
            and ((other_phase1_voltage > OT_2) or (other_phase2_voltage > OT_2)))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((phase_voltage > RT_1)
            and (phase_current > RT_3)
            and ((other_phase1_voltage > RT_2) or (other_phase2_voltage > RT_2)))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic2:
    {
        if ((phase_voltage < OT_1)
            and (phase_current > OT_3)
            and ((other_phase1_voltage > OT_2) or (other_phase2_voltage > OT_2)))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((phase_voltage > RT_1)
            or (phase_current < RT_3)
            or (other_phase1_voltage < RT_2) or (other_phase2_voltage < RT_2))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
    
    case TamperDetectionLogic3:
    {
        if ((phase_voltage < OT_1) and (phase_current < OT_3))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((phase_voltage > RT_1) and (phase_current > RT_3))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic4:
    {
        if ((phase_voltage < OT_1)
            and (other_phase_voltages > OT_2) 
            and (other_phase_voltages < OT_5)
            and (phase_current > OT_3))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((phase_voltage > RT_1)
            and (other_phase_voltages > RT_2) 
            and (other_phase_voltages < RT_5)
            and (phase_current > RT_3))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
}
