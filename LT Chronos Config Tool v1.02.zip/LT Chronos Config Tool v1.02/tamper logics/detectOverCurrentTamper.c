if ((logic is TamperDetectionDisabled)
    or (relay state is not RelaySwitchConnected))
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    {
        if ((max current > OT_1) and (phase voltage > OT_2))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((max current < RT_1) and (phase voltage > RT_2))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
    
    case TamperDetectionLogic2:
    {
        if ((min voltage > OT_2 and max voltage < OT_3 and max current > OT_1))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((min voltage > RT_2 and max voltage < RT_3 and max current < RT_1))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
}