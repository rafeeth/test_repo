if (logic is TamperDetectionDisabled)
{
    tamperStatus = Unknown;
    return;
}

if (temperature > OT_1)
    tamperStatus = Occurrence;
else if (temperature < RT_1)
    tamperStatus = Recovery;