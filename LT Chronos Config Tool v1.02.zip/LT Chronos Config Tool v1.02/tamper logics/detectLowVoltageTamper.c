if (logic is TamperDetectionDisabled)
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    {
        if ((min voltage > OT_1) and (min voltage < OT_2) and (avg voltage > OT_3))
        {
            tamperState = TamperStateOccurrence;
        }
        else if (((min voltage < RT_1) or (min voltage > RT_2)) and (avg voltage > RT_3))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic2:
    {
        if ((min voltage > OT_1) and (min voltage < OT_2) and (max current > OT_5))
        {
            tamperState = TamperStateOccurrence;
        }
        else if (min voltage > RT_2)
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic3:
    {
        if (min voltage > RT_2)
        {
            tamperState = TamperStateRecovery;
        }
        else for each phase
        {
            if ((phase voltage > OT_1) and (phase voltage < OT_2) and (phase current > OT_5))
            {
                tamperState = TamperStateOccurrence;
            }
        }
    }
    break;
}