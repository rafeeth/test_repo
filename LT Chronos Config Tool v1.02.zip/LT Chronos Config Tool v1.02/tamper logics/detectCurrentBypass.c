if ((logic is TamperDetectionDisabled)
        or ((noCurrentReversalTamperCheck) and (anyPhaseReversed))
        or ((noCurrentOpenTamperCheck) and (currentOpenTamperDetected))
        or (relay state is not RelaySwitchConnected))
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    {
        if ((min current > OT_2)
            and (max current > OT_3)
            and (avg current > OT_4)
            and (min voltage > OT_5))
        {
            if (bypass current > OT_1)
                tamperState = TamperStateOccurrence;
            else if (bypass current < RT_1)
                tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic2:
    {
        if ((bypass current > OT_1)
            and (min current > OT_2)
            and (max current > OT_3)
            and (avg current > OT_4)
            and (min voltage > OT_5))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((bypass current < RT_1)
            or (min current < RT_2)
            or (max current < RT_3)
            or (avg current < RT_4)
            or (min voltage < RT_5))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
}