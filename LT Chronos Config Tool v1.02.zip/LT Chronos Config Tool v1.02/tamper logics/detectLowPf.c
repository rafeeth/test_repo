if ((logic is TamperDetectionDisabled)
    or (relay state is not RelaySwitchConnected))
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    {
        standard logic
        Current reversal tamper detection logic sets Low PF flags
    }
    break;

    case TamperDetectionLogic2:
    {
        for each phase
        {
            if ((phase voltage > OT_3)
                and (phase current > OT_2)
                and (phase PF < OT_1))
            {
                tamperState = TamperStateOccurrence;
                break;
            }
            else if ((phase voltage > RT_3)
                and (phase current > RT_2)
                and (phase PF > RT_1))
            {
                tamperState = TamperStateRecovery;
            }
            else if (tamper is logged)
            {
                tamperState = TamperStateUnknown;
                break;
            }
        }
    }
    break;

    case TamperDetectionLogic3:
    {
        tamperState = TamperStateUnknown;

        if ((abs(net PF) < OT_1) and (min current > OT_2))
            tamperState = TamperStateOccurrence;
        else if ((abs(net PF) > RT_1) and (min current > RT_2))
            tamperState = TamperStateRecovery;
    }
    break;
    
    case TamperDetectionLogic4:
    {
        tamperState = TamperStateUnknown;

        if(min voltage > 180 volts) and (max voltage < 276 volts)
        {
            if ((abs(net PF) < OT_1) and (min current > OT_2))
                tamperState = TamperStateOccurrence;
            else if ((abs(net PF) > RT_1) and (min current > RT_2))
                tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic5:
    {
        for each phase
        {
            if ((phase current > 1 Amps)
                and (phase voltage > 156 volts))
            {
                if ((kW is -ve)
                    and (net kW > -240000)
                    and ((phase PF < 0.3) or (phase kW < 120 Watts)))
                {
                    tamperState = TamperStateOccurrence;
                }
                else if (all phases are +ve)
                {
                    tamperState = TamperStateRecovery;
                    break;
                }
            }
        }
    }
    break;
    
    case TamperDetectionLogic6:
    {
        if ((abs(net PF) < OT_1) and (min current > OT_2) and (OT_4 > all voltages > OT_3))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((abs(net PF) > RT_1) and (min current > RT_2) and (RT_4 > all voltages > RT_3)))
        {
            tamperState = TamperStateRecovery;
        }    
    }
    break;
}