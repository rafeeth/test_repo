if ((logic is TamperDetectionDisabled)
    or (relay state is not RelaySwitchConnected))
{
    meterGlobal.tamperInfo[TTOverLoad].status = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    {
        if ((abs(net kW) > OT_1) or (abs(net kW) > limiterThreshold))
            tamperState = TamperStateOccurrence;
        else if ((abs(net kW) < RT_1) and (abs(net kW) < limiterThreshold))
            tamperState = TamperStateRecovery;
    }
    break;
}