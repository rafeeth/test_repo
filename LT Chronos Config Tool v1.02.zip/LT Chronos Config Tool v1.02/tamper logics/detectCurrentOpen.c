if ((logic is TamperDetectionDisabled)
    or ((reverseTamperCheck) and (anyPhaseReversed))
    or (relay state is not RelaySwitchConnected))
{
    tamperState = TamperStateUnknown;
    return;
}

switch (logic)
{
    default:
    case TamperDetectionLogic1:
    {
        if ((phase current < OT_1)
            and (bypass current > OT_2)
            and (phase voltage > OT_3)
            and (min voltage > OT_4))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((phase current > RT_1)
            and (bypass current < RT_2)
            and (phase voltage > RT_3)
            and (min voltage > RT_4))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic2:
    {
        if ((phase current < OT_1)
            and (bypass current > OT_2)
            and (phase voltage > OT_3)
            and (min voltage > OT_4))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((phase current > RT_1)
            or (bypass current < RT_2)
            or (phase voltage < RT_3)
            or (min voltage < RT_4))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic3:
    {
        if ((min voltage > OT_4) and (phase current < OT_1) and (max current > OT_6))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((min voltage > RT_4) and (phase current > RT_1) and (max current > RT_6))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
    
    case TamperDetectionLogic4:
    {
        if ((phase current < OT_1)
            and (bypass current > OT_2)
            and (max voltage < OT_3)
            and (min voltage > OT_4))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((phase current > RT_1)
            and (bypass current < RT_2)
            and (max voltage < RT_3)
            and (min voltage > RT_4))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;

    case TamperDetectionLogic5:
    {
        if(metering mode is not unidirectional) break;
        
        if ((phase current < OT_1)
            and (bypass current > OT_2)
            and (max voltage < OT_3)
            and (min voltage > OT_4)
            and (average current > OT_6))
        {
            tamperState = TamperStateOccurrence;
        }
        else if ((phase current > RT_1)
            and (bypass current < RT_2)
            and (max voltage < RT_3)
            and (min voltage > RT_4)
            and (average current > RT_6))
        {
            tamperState = TamperStateRecovery;
        }
    }
    break;
}