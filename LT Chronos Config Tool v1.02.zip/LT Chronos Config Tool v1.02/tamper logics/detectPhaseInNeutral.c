if (logic is TamperDetectionDisabled)
    return;

switch(tamper logic)
{
    case TamperDetectionLogic1:
        Phase in neutral detection
    break;

    case TamperDetectionLogic2:
        Current without voltage
    break;
}
